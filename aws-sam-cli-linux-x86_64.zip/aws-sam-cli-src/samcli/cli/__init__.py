"""
CLI Framework
"""
